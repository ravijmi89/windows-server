#>

$strComputer=$env:computername

# Import CSV to $AllUsers
$AllUsers = Import-CSV "C:\User.csv"

foreach ($User in $AllUsers)
      {
      write-host Creating user account $user.Username

      $objOU = [adsi]"WinNT://."

      # Create user account
      $objUser = $objOU.Create("User", $User.Username)

      # Set password
      $objuser.setPassword($User.Password)

      # Set FullName
      $objUser.put("FullName",$User.FullName)

      # Set Description
      $objUser.put("Description",$User.Description)

      # User must change password on next log on
      #$objuser.PasswordExpired = 0

      # User cannot change password and never expire
      $objUser.UserFlags = 64 + 65536



      # Save the info
      $objuser.SetInfo()

      # Add each user account to local Administrators group
      $computer = [ADSI]("WinNT://" + $strComputer + ",computer")
      $group = $computer.psbase.children.find("Remote Desktop Users")
      $group.Add("WinNT://" + $strComputer + "/" + $user.Username)

      # Option add each user account to Second users group
      #$computer = [ADSI]("WinNT://" + $strComputer + ",computer")
      #$group = $computer.psbase.children.find("Second users")
      #$group.Add("WinNT://" + $strComputer + "/" + $user.Username)

      } 